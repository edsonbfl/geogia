class PersonController {

	def scaffold = org.gerp.party.Person
	
}

