class PartyController {
	
	def scaffold = org.gerp.party.Party
	
}

