class PersonControllerTests extends GroovyTestCase {

	void testSomething() {
		
	}
}
