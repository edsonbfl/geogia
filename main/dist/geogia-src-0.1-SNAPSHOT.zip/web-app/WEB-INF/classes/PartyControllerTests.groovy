class PartyControllerTests extends GroovyTestCase {

	void testSomething() {
		
	}
}
