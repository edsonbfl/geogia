class PartyTests extends GroovyTestCase {

	void testSomething() {
		
	}
}
