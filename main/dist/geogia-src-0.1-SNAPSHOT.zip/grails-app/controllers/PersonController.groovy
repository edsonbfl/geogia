class PersonController {

	def scaffold = org.geogia.party.Person
	
}

