class PartyController {
	
	def scaffold = org.geogia.party.Party
	
}

