package org.geogia.party

class Person extends Party {
	
	String firstName
	String middleName
	String lastName
	String personalTitle
	String suffix
	String nickName
	String memberID
	Boolean gender
	Date birthDate
	Double height
	Double weight
	String mothersMaidenName
	String maritalStatus
	String socialSecurityNumber
	String passportNumber
	Date passportExpireDate
	Double totalYearsWorkExperience
	String comments
	
}