package org.geogia.party

class Party { 
	
	String partyID
	String externalID
	Date createdDate
	Date lastModifiedDate
	String pName
	String searchName
	Double creditLimit
	
}	
