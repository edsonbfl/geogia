package org.geogia.party

class Company extends Party {

	String siret
	String siren
	String corparateName
	String sigle
	String countryCode
	String lang
	String gln
	String packerCode
	String euroVatCode
	
}	
