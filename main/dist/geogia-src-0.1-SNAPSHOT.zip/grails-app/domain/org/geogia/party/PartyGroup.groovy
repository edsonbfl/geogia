package org.geogia.party

class PartyGroup extends Party {
	
	String groupName
	String groupNameLocal
	String officeSiteName
	String comments
	String logoImageUrl
	
}	
