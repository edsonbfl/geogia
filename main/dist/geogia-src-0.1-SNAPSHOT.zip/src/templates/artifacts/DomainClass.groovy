class @artifact.name@ { 
}	
