class @artifact.name@ {

	def index = { }
}

