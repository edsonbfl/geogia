class @artifact.name@ extends GroovyTestCase {

	void testSomething() {
		
	}
}
