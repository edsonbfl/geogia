class @artifact.name@ {

}